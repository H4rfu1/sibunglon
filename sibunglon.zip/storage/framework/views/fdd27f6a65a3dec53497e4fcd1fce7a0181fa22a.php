<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="">
        <h3>Selamat Datang <small> <br>
        <?php if(Auth::user()->id_role == 1): ?>
        <?php echo e('Administrator'); ?>

        <?php echo e(Auth::user()->name); ?>

        <?php endif; ?>
        <?php if(Auth::user()->id_role == 2): ?>
        <?php echo e('Pengawas'); ?>

        <?php echo e(Auth::user()->name); ?>

        <?php endif; ?>
        <?php if(Auth::user()->id_role == 3): ?>
        <?php echo e('Pemimpin'); ?>

        <?php echo e(Auth::user()->name); ?>

        <?php endif; ?>
        </small></h3>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\sibunglon\resources\views/home.blade.php ENDPATH**/ ?>