<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="">
        <h3>Kelola Akun Pemimpin</h3>
        <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_content">
                  <a class="btn btn-primary" href="<?php echo e(url('buatakun/3')); ?>">Tambah akun pimpinan</a>
                    <?php if(session('status')): ?>
                      <div class="alert alert-success alert-dismissible " role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <?php echo e(session('status')); ?>

                      </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title">No. </th>
                            <th class="column-title">Nama</th>
                            <th class="column-title">email </th>
                            <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php $__currentLoopData = $pemimpin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($loop->iteration % 2 == 1): ?>
                          <tr class="even pointer" onclick="window.location='<?php echo e(url('profil/'.$p->id)); ?>';" style="cursor: pointer;">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->email); ?></td>
                            <td class=" last"><a href="<?php echo e(url('profil/'.$p->id)); ?>"><span class="badge badge-info">Detail</span></a>
                            </td>
                          </tr>
                          <?php else: ?>
                          <tr class="odd pointer" onclick="window.location='<?php echo e(url('profil/'.$p->id)); ?>';" style="cursor: pointer;">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->email); ?></td>
                            <td class=" last"><a href="<?php echo e(url('profil/'.$p->id)); ?>"><span class="badge badge-info">Detail</span></a>
                            </td>                            
                          </tr>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
							
						
                  </div>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\sibunglon\resources\views/akun/V_AkunPimpinan.blade.php ENDPATH**/ ?>