<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="">
        <h3>Kelola Akun Pencatatan</h3>
        <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_content">
                  <?php if(Auth::user()->id_role == 2): ?>
                  <a class="btn btn-primary" href="<?php echo e(url('inputpencatatan')); ?>">Tambah Pencatatan</a>
                  <?php endif; ?>
                    <?php if(session('status')): ?>
                      <div class="alert alert-success alert-dismissible " role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <?php echo e(session('status')); ?>

                      </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title">ID. Pencatatan</th>
                            <th class="column-title">No. Greenhouse</th>
                            <th class="column-title">Pengawas</th>
                            <th class="column-title">Tanggal tanam</th>
                            <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php $__currentLoopData = $datapencatatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($loop->iteration % 2 == 1): ?>
                          <?php if( Auth::user()->id_role == 2): ?>
                          <tr class="even pointer">
                          <?php else: ?>
                          <tr class="even pointer" onclick="window.location='<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>';" style="cursor: pointer;">
                          <?php endif; ?>
                            <td><?php echo e($p->id_dataperawatan); ?></td>
                            <td class=" "><?php echo e($p->no_greenhouse); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->tanggal_tanam); ?></td>
                            <?php if( Auth::user()->id_role == 2): ?>
                            <td class=" last">
                              <!-- <a href="#" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($p->id_dataperawatan); ?>" class="text-decoration-none"><span class="badge badge-danger" style="font-size: 1em;">Hapus</span></a> -->
                              <a href="<?php echo e(url('editpencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-warning" style="font-size: 1em;">Ubah</span></a>
                              <a href="<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-info" style="font-size: 1em;">Detail</span></a>           
                            </td>
                            <?php else: ?>  
                            <td class=" last">
                              <!-- <a href="#" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($p->id_dataperawatan); ?>" class="text-decoration-none"><span class="badge badge-danger" style="font-size: 1em;">Hapus</span></a> -->
                              <a href="<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-info" style="font-size: 1em;">Detail</span></a>           
                            </td>         
                            <?php endif; ?>     
                          </tr>
                          <?php else: ?>
                          <?php if( Auth::user()->id_role == 2): ?>
                          <tr class="odd pointer">
                          <?php else: ?>
                          <tr class="odd pointer" onclick="window.location='<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>';" style="cursor: pointer;">
                          <?php endif; ?>                            
                          <td><?php echo e($p->id_dataperawatan); ?></td>
                            <td class=" "><?php echo e($p->no_greenhouse); ?></td>
                            <td class=" "><?php echo e($p->name); ?></td>
                            <td class=" "><?php echo e($p->tanggal_tanam); ?></td>
                            <?php if( Auth::user()->id_role == 2): ?>
                            <td class=" last">
                              <!-- <a href="#" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($p->id_dataperawatan); ?>" class="text-decoration-none"><span class="badge badge-danger" style="font-size: 1em;">Hapus</span></a> -->
                              <a href="<?php echo e(url('editpencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-warning" style="font-size: 1em;">Ubah</span></a>
                              <a href="<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-info" style="font-size: 1em;">Detail</span></a>           
                            </td>
                            <?php else: ?>  
                            <td class=" last">
                              <!-- <a href="#" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo e($p->id_dataperawatan); ?>" class="text-decoration-none"><span class="badge badge-danger" style="font-size: 1em;">Hapus</span></a> -->
                              <a href="<?php echo e(url('pencatatan/'.$p->id_dataperawatan)); ?>"><span class="badge badge-info" style="font-size: 1em;">Detail</span></a>           
                            </td>         
                            <?php endif; ?>                 
                          </tr>
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <form id="delete-form" action="" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('delete'); ?>
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Apakah anda yakin ingin hapus?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Hapus</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\sibunglon\resources\views/pencatatan/V_DataPencatatan.blade.php ENDPATH**/ ?>