<?php $__env->startSection('judul1', 'Input Pencatatan | '); ?>
<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3> Pencatatan perkembangan melon</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2> Form Pencatatan
                        </h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form class="" action="<?php echo e(url('simpanpencatatan')); ?>" method="post" novalidate>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="pencatat" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Jenis Melon<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6">
                                    <select name="jenis_melon" id="jenis_melon" class="form-control" required='required'>
                                        <option value="" disabled selected></option>
                                    <?php $__currentLoopData = $jenismelon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="form-control" value="<?php echo e($item->id_jenismelon); ?>" ><?php echo e($item->jenismelon); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">No Greenhouse<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6">
                                <select name="no_greenhouse" id="no_greenhouse" class="form-control" required='required'>
                                    <option value="" disabled selected></option>
                                    <?php $__currentLoopData = $nogrenhouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="form-control" value="<?php echo e($item->id_greenhouse); ?>" ><?php echo e($item->no_greenhouse); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="field item form-group">
                                <label class="col-form-label col-md-3 col-sm-3  label-align">Tanggal Tanam<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6">
                                    <input class="form-control" class='date' type="date" name="tanggal_tanam" required='required'></div>                                            
                            </div>
                            <div class="ln_solid">
                                <div class="form-group">
                                    <div class="col-md-6 offset-md-3 mt-2">
                                        <a class="btn btn-danger" href = "<?php echo e(url('pencatatan')); ?>">Batal</a>
                                        <button type='submit' class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashinput', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aplikasi\xampp\htdocs\sibunglon\resources\views/pencatatan/V_InputPencatatan.blade.php ENDPATH**/ ?>